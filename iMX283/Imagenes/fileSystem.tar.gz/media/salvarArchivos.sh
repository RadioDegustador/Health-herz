rm files.tar.gz
cd /
rm files.tar.gz
tar zcvf files.tar.gz etc/hostapd* 
usr/share/openocd/scripts/interface/sysfsgpio-imx283.cfg /media/ 
/dev/ttySP*
mv files.tar.gz /media/
cd /media

