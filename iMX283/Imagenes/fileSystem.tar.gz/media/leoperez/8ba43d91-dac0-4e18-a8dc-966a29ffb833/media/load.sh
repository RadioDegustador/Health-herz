#!/bin/sh

openocd -f reset.cfg
xc3sprog -c imx283 -v -p1 sram.bit
rm /media/datos.csv
cp /home/datos.csv /media/
openocd -f digital_design.cfg
#sleep 2
#sh server.sh
