#!/bin/sh

openocd -f reset.cfg
xc3sprog -c imx283 -v -p1 sram.bit
openocd -f digital_design.cfg
