ifconfig wlan0 up &
ifconfig wlan0 192.168.0.1
/etc/hostapd /etc/hostapd.conf &
python /media/Server/server.py

