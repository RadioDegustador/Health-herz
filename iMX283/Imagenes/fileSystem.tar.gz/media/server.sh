ifconfig wlan0 192.168.0.1 up
sleep 3
/etc/hostapd /etc/hostapd.conf &
sleep 3
echo "Ejecuto python"
python /media/Server/server.py
