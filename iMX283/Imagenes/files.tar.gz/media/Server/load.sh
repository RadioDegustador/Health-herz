python prueba_escribir_csv.py &
python server.py
